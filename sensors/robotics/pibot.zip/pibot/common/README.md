# Sentinel Smart Sensor Utilities

###_TODO: This document needs to be updated when code is complete_

